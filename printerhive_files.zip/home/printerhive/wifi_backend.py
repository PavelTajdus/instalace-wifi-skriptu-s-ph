from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route('/wifi', methods=['POST'])
def set_wifi():
    ssid = request.form['ssid']
    psk = request.form['password']

    try:
        with open('/home/printerhive/printerhive-wifi.conf', 'w') as f:
            f.write(f"ssid={ssid}\npsk={psk}\n")
        subprocess.Popen(['sudo', 'reboot'])
        return "WiFi credentials saved.", 200
    except Exception as e:
        return f"Failed to save WiFi credentials: {str(e)}", 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
