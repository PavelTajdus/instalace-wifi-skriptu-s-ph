#!/bin/bash
set -e

sleep 10

WIFI_CONF="/home/printerhive/printerhive-wifi.conf"

if [ -f "$WIFI_CONF" ]; then
    SSID=$(grep '^ssid=' "$WIFI_CONF" | cut -d'=' -f2-)
    PSK=$(grep '^psk=' "$WIFI_CONF" | cut -d'=' -f2-)

    echo "Zkouším připojit k WiFi $SSID..."
    sudo systemctl stop my-hotspot.service
    sudo systemctl stop my-captive-portal.service
    sudo systemctl stop hostapd
    sudo systemctl stop dnsmasq
    sudo systemctl stop wlan0-static
    sudo systemctl start NetworkManager
    sleep 3
    sudo nmcli device set wlan0 managed yes
    sudo systemctl restart NetworkManager
    sleep 3
    sudo nmcli device wifi connect "$SSID" password "$PSK"
    sleep 5

    # Ověř, že jsme připojení
    if iwgetid -r; then
        echo "WiFi připojeno, hotspot nespouštím."
        exit 0
    else
        echo "Připojení k WiFi selhalo, spouštím hotspot."
    fi
fi

echo "WiFi NENÍ připojeno, spouštím hotspot a captive portal."
sudo systemctl stop NetworkManager
sudo systemctl start wlan0-static
sudo ip link set wlan0 up
sudo systemctl start hostapd
sudo systemctl start dnsmasq
sudo systemctl start my-hotspot.service
sudo systemctl start my-captive-portal.service
